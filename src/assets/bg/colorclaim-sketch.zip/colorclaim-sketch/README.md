# Color Claim for Sketch

# Installation

#### Get the Sketch Palettes Plugin

<a href="https://github.com/andrewfiorillo/sketch-palettes/releases">Install Sketch Palettes Plugin</a>

#### Choose Color Claim Version

There is a version of the Color Claim palette for the 1.1 version of Sketch Palettes and the 1.5 version.

#### Loading Palettes

(copied on 11/17/2016 from the Sketch Palettes read me)  

You can load colors into either the Global Colors section of the color picker or into the Document Colors section. Selecting "Load Palette..." from either menu will prompt you to open a .sketchpalette file containing the colors you want to load. This will replace whatever colors are currently in the selected section.

#### Removing Palettes

(copied on 11/17/2016 from the Sketch Palettes read me. You might need to clear palettes before successfully loading a new palette.)  

Select "Clear Palette" to remove all colors from either the Global Colors section of the color picker or from the Document Colors section.

# Info & Feedback

Color Claim was created by <a href="https://twitter.com/vanschneider" target="_blank">@vanschneider</a>

Color Claim was ported into a .sketchpalettes file by <a href="https://twitter.com/conwayanderson" target="_blank">@conwayanderson</a>  

The Sketch Palettes plugin was created by <a href="https://twitter.com/AndrewFiorillo" target="_blank">@andrewfiorillo</a>
